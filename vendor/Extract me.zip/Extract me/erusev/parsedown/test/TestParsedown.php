<?php

class TestParsedown extends Parsedown
{
}
